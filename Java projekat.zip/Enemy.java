package vjezbenedelja3;

class Enemy {
	private int x; //Ovo su nam atributi za klasu koji nam predstavljaju poziciju, veličinu i hp neprijatelja
	private int y;
	private int width;
	private int height;
	private int damage; //0-100
	
	Enemy(int x, int y, int width, int height, int damage) {
		super();
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.damage = damage;
		
	
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}
	
	

}
