package vjezbenedelja3;
// SEMIR BRALIĆ 23/050, DANIS NUMANOVIĆ 23/074, EMIR BALIJAGIC 23/075
public class Game {

	public static void main(String[] args) {
		
		Player player = new Player(50, 50, 30, 30, 100); // Kreiramo igraca na poziciji (50,50) sa velicinom 30x30 i zdravljem 100
		Enemy enemy = new Enemy(60, 60, 30, 30, 20); // Kreiramo neprijatelja na poziciji (60,60) sa velicinom 30x30 i damage-om 20
		Enemy enemy2 = new Enemy(200, 200, 30, 30, 15); // Kreiramo drugog neprijatelja na poziciji (200,200) sa velicinom 30x30 i damage-om 15
		
		System.out.println("Igracovo zdravlje pre kolizije: " + player.getHealth());
		player.checkCollision(enemy); // Proveravamo koliziju izmedju igraca i neprijatelja
		System.out.println("Igracovo zdravlje posle kolizije: " + player.getHealth());
		
		

	}

}
