package vjezbenedelja3;

class Player {
	private int x; //Ovo su nam atributi za klasu koji nam predstavljaju poziciju, veličinu i hp igrača 
	private int y;
	private int width;
	private int height;
	private int health; //0-100
	
	
	
	Player(int x, int y, int width, int height, int health) {
		super();
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.health = health;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	
	public void checkCollision(Enemy enemy) {
		if(this.x < enemy.getX() + enemy.getWidth() &&
		   this.x + this.width > enemy.getX() &&
		   this.y < enemy.getY() + enemy.getHeight() &&
		   this.y + this.height > enemy.getY()) {
			// Kolizija je detektovana
			this.health -= enemy.getDamage(); // Smanjujemo zdravlje igraca za damage neprijatelja
			if(this.health < 0) {
				this.health = 0; // Zdravlje ne moze ici ispod 0
			}
			return;
		}
		return;
	}
	
	
	
	

}
