package vjezbenedelja5;

class Enemy {
 private String type; // tip neprijatelja na primjer goblin
 private int x, y, width, height;
 private int damage; //u slučaju kolizije, koliko healtha oduzima plejeru

 public Enemy(String type, int x, int y, int width, int height, int damage) {  // Konstruktor
     setType(type);
     this.x = x;
     this.y = y;
     this.width = width;
     this.height = height;
     setDamage(damage);
 }

 public void setType(String type) { // Metoda koja provjerava da li je tip neprijatelja koji je dat prazan
     if (type == null || type.trim().isEmpty()) throw new IllegalArgumentException("Tip ne smije biti prazan");
     this.type = type.trim();
 }

 public void setDamage(int damage) { // Metoda koja zaključuje da je damage između 0 i 100
     this.damage = Math.max(0, Math.min(100, damage));
 }

 public String getType() { return type; } // Getteri za sve atribute
 public int getX() { return x; }
 public int getY() { return y; }
 public int getWidth() { return width; }
 public int getHeight() { return height; }
 public int getDamage() { return damage; }

 @Override
 public String toString() { // Omogućava ispis informacija o neprijatelju
     return "Enemy[" + type + "] @ (" + x + "," + y + ") " + width + "x" + height + " DMG=" + damage;
 }
}
