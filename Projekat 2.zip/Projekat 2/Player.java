package vjezbenedelja5;

//Članovi grupe: Semir Bralić 23/050, Emir Balijagić 23/083

class Player {
 private String name;  // Atributi
 private int x, y, width, height; // Pozicija na x i y koordinati, širina plejera i visina plejera
 private int health; // Zdravlje plejera (0-100) ja sam hteo hitpoints embo je hteo zdravlje

 public Player(String name, int x, int y, int width, int height, int health) {   // Konstruktor
     setName(name);
     this.x = x;  
     this.y = y;
     this.width = width;
     this.height = height;
     setHealth(health);
 }

 public void setName(String name) {  //Metoda za ime i provjerava da li je ime prazno i mijenja prvo slovo imena u veliko slovo i uklanja razmake
     if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Ime ne smije biti prazno");
     name = name.trim().replaceAll("\\s+", " ");
     String[] words = name.split(" ");
     StringBuilder formatted = new StringBuilder();
     for (String word : words) {
         formatted.append(Character.toUpperCase(word.charAt(0)))
                  .append(word.substring(1).toLowerCase()).append(" ");
     }
     this.name = formatted.toString().trim();
 }

 public void setHealth(int health) {  // Metoda za zdravlje koja osigurava da zdravlje bude između 0 i 100
     this.health = Math.max(0, Math.min(100, health));
 }

 public String getName() { return name; } // Getteri za sve atribute
 public int getX() { return x; }
 public int getY() { return y; }
 public int getWidth() { return width; }
 public int getHeight() { return height; }
 public int getHealth() { return health; }

 @Override
 public String toString() { // Omogućava ispis informacija o plejeru
     return "Player [" + name + "] @ (" + x + "," + y + ") " + width + "x" + height + " HP=" + health;
 }
}
