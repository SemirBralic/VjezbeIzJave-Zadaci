package vjezbenedelja4;
/*kreirati klasu AnalizaNiza koja sadrži metodu nadjiParniPozitivniProsjek koja prima niz cijelih brojeva i izračunava prosječnu vrijednost svih pozitivnih parnih brojeva
 * u nizu. U testnoj klasi omogućiti korisniku da unese elemente niza, a zatim koristeći kreiranu metodu izračunati i ispisati prosječnu vrijednost parnih brojeva unijetog 
 * niza
 */
import java.util.Scanner;

class Metoda {
    public static double nadjiParniPozitivniProsjek(int[] niz) {
        int suma = 0;
        int brojac = 0;

        for (int brojNiza : niz) {
            if (brojNiza > 0 && brojNiza % 2 == 0) {
                suma += brojNiza;
                brojac++;
            }
        }

        if (brojac == 0) {
            return 0; 
        }

        return (double) suma / brojac;
    }
}

public class AnalizaNiza {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Unesite broj elemenata niza: ");
        int n = scanner.nextInt();

        int[] niz = new int[n];
        System.out.println("Unesite " + n + " cijelih brojeva:");
        for (int i = 0; i < n; i++) {
            niz[i] = scanner.nextInt();
        }

        double prosjek = Metoda.nadjiParniPozitivniProsjek(niz);

        if (prosjek == 0) {
            System.out.println("Nema pozitivnih parnih brojeva u nizu.");
        } else {
            System.out.println("Prosječna vrijednost pozitivnih parnih brojeva je: " + prosjek);
        }

        scanner.close();
    }
}
