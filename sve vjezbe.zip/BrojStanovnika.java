package vjezbe1;
import java.util.Scanner;
public class BrojStanovnika {

	public static void main(String[] args) {
		try (Scanner unos = new Scanner(System.in)) {
			System.out.println("Unesite broj stanovnika u prvom gradu: ");
			int brojStanovnika1 = unos.nextInt();
			System.out.println("Unesite broj stanovnika u drugom gradu: ");
			int brojStanovnika2 = unos.nextInt();
			System.out.println("Unesite broj stanovnika u trecem gradu: ");
			int brojStanovnika3 = unos.nextInt();
			System.out.println("Unesite broj stanovnika u cetvrtom gradu: ");
			int brojStanovnika4 = unos.nextInt();
			int ukupnoStanovnika = brojStanovnika1 + brojStanovnika2 + brojStanovnika3 + brojStanovnika4;
			System.out.println("Ukupan broj stanovnika u sva cetiri grada je: " + ukupnoStanovnika);
			int prosjekStanovnika = ukupnoStanovnika / 4;
			System.out.println("Prosjek broja stanovnika u sva cetiri grada je: " + prosjekStanovnika);
		}

	}

}
