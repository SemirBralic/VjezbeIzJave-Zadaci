package vjezbe1;
import java.util.Scanner;
public class Dron {

	    public static void main(String[] args) {
	        try (Scanner unos = new Scanner(System.in)) {
				System.out.print("Unesi koordinate x drona: ");
				double x = unos.nextDouble();
				System.out.print("Unesi koordinate y drona: ");
				double y = unos.nextDouble();
				
				System.out.print("Unesi broj paketa: ");
				int n = unos.nextInt();

				double ukupnaUdaljenost = 0;

				for (int i = 0; i < n; i++) {
				    System.out.println("Unesi koordinate paketa" + (i + 1));
				    System.out.print("x" + (i + 1) + ": ");
				    double xi = unos.nextDouble();
				    System.out.print("y" + (i + 1) + ": ");
				    double yi = unos.nextDouble();
				    
				    if (xi > 0 && yi > 0) {
				        double udaljenost = Math.sqrt(Math.pow(xi - x, 2) + Math.pow(yi - y, 2));
				        ukupnaUdaljenost += udaljenost;
				  }
				}
				System.out.printf("Ukupna udaljenost do paketa u prvom kvadrantu je: %.2f\n", ukupnaUdaljenost);
			}
	    }
}