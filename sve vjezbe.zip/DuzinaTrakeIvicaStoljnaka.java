package vjezbe1;
import java.util.Scanner;

public class DuzinaTrakeIvicaStoljnaka {
//Napisati program kojim se izracunava potrebna dužina trake za ivicu stolnjaka kružnog oblika čija je površina P 

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite površinu");
		double povrsina = sc.nextDouble();
		double r = Math.sqrt(povrsina/Math.PI);
		double obim = 2*r*Math.PI;
		System.out.println("Trake nam je potrebno"+obim);
		sc.close();
		
	}

}
