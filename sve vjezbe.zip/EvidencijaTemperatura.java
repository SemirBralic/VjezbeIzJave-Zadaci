package vjezbenedelja4;

public class EvidencijaTemperatura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
