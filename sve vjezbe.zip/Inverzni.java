package vjezbenedelja4;

public class Inverzni {

	public static void main(String[] args) {
		

	}

}
