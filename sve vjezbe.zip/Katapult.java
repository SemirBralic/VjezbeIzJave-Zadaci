package vjezbe1;
import java.util.Scanner;
public class Katapult {

	public static void main(String[] args) {
		try (Scanner unos = new Scanner(System.in)) {
			System.out.println("Unesi broj katapulta: ");
			int N = unos.nextInt();
			System.out.println("Prihvatljiva udaljenost katapulta da uradi damage: ");
			long D = unos.nextLong();
			System.out.println("Unesi health dvorca: ");
			long HD = unos.nextLong();
			System.out.println("Unesi damage katapulta: ");
			long KA = unos.nextLong();
			int brojprijetnji = 0;
			
			for (int i = 0; i < N; i++) {
				System.out.println("Unesi koordinate katapulta: ");
				long x=unos.nextLong();
				long y=unos.nextLong();
				long menheten = Math.abs(x) + Math.abs(y);
				
				if (menheten <= D) {
					brojprijetnji++;
				}
			}
			long ukupnidamage = brojprijetnji * KA;
			System.out.println(brojprijetnji);
			System.out.println(ukupnidamage);
			if (ukupnidamage >= HD) {
				System.out.println("Dvorac je srusen, ukupan damage je: " + ukupnidamage);
			} else {
				System.out.println("Dvorac je spasen");
			}
		}
	}
}


