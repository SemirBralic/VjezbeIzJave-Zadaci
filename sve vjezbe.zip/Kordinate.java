package vjezbe1;
import java.util.Scanner;
public class Kordinate {

	public static void main(String[] args) {
	// Date su koordinate donje desne i gornje lijeve ivice zida (pravougaonik). Napisati program koji računa površinu i obim zida.
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite kordinate");
		double x1 = sc.nextDouble(), x2 = sc.nextDouble(), y1 = sc.nextDouble(), y2 = sc.nextDouble();
		double širina = Math.abs(x1-x2);
		double visina = Math.abs(y2-y1);
		
		double površina = širina * visina;
		double obim = 2*(širina+visina);
		System.out.println("Površina je: "+površina+"a obim je: "+obim);
		sc.close();
	}

}
