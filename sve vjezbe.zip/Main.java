package vjezbenedelja3;

public class Main {

	public static void main(String[] args) {
		
		Televizor tv = new Televizor(5, "RTCG2", 7);
		tv.ispisi();
		tv.pojacajTon();
		System.out.println("Posle pojacavanja tona:");
		tv.ispisi();
		
		tv.setNazivKanala("HBO");
		tv.setBrojKanala(10);
		tv.setJacinaTona(5); 
		System.out.println("Posle promene kanala i jacine tona:");
		tv.ispisi();
		

	}

}
