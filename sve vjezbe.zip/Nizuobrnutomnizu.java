package vjezbenedelja4;
//napisati program koji kreira niz od 10 elemenata popunjava ga brojevima od 1 do 10 a zatim ispisuje niz u obrnutom redoslijedu
public class Nizuobrnutomnizu {

	public static void main(String[] args) {
		int[] niz = new int[10];
		for (int i = 0; i < niz.length; i++) {
			niz[i] = i + 1;
			System.out.print(" " + niz[i]);
		}
		System.out.println(" " +"Niz u obrnutom redoslijedu:");
		for (int i = niz.length - 1; i >= 0; i--) { //ako je i = elemntu u kojem se nalazi a i je veće ili jednako 0 i se smanjuje za 1
			System.out.print(niz[i] + " ");
		}

	}

}
