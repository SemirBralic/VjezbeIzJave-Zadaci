package vjezbe1;

import java.util.Scanner;

public class PovrsinaPapiraUcm2 {

	public static void main(String[] args) {
		try (
				Scanner sc = new Scanner(System.in)) {
					System.out.println("Unesite širinu ");
					double sirina = sc.nextDouble();
					System.out.println("Unesite dužinu ");
					double duzina = sc.nextDouble() ;
					double povrsina = (duzina * sirina)/100;
					
					System.out.println("Površina pravougaonika je " + povrsina);

		}

	}
}
