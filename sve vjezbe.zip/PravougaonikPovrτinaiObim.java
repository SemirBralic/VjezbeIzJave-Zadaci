package vjezbe1;
import java.util.Scanner;
public class PravougaonikPovršinaiObim {

	public static void main(String[] args) {
	//Moze da radi bez ovog try ali ima neki resource leak nesto
	//Napisati program koji računa povrsinu i obim pravougaonika na osnovu zadatih dimenzija
		try (
			Scanner sc = new Scanner(System.in)) {
				System.out.println("Unesite širinu pravougaonika");
				double sirina = sc.nextDouble();
				System.out.println("Unesite dužinu pravougaonika");
				double duzina = sc.nextDouble() ;
				double povrsina = duzina * sirina;
				double obim = 2 * duzina + 2 * sirina;
				System.out.println("Površina pravougaonika je " + povrsina + ", obim je " + obim);
			}
			

	}

}
