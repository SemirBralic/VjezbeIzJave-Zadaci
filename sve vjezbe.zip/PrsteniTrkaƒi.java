package vjezbe1;
import java.util.Scanner;
public class PrsteniTrkači {
/*da bi provjerili je li trkač unutar prstena, gledamo je li mu euklidska udaljenost od centra manja od r2(koji je veci od r1), a veća od r1,
 * a da bi provjerili je li trkač u gornjom kvadrantu gledamo je li mu y koordinata veća od Cy
 */
	public static void main(String[] args) {
		try (Scanner unos = new Scanner(System.in)) {
			System.out.println("Unesite koordinate centra prstena (Cx, Cy): ");
			double Cx = unos.nextDouble();
			double Cy = unos.nextDouble();
			System.out.println("Unesite unutarnji poluprečnik prstena r1: ");
			double r1 = unos.nextDouble();
			System.out.println("Unesite vanjski poluprečnik prstena r2: ");
			double r2 = unos.nextDouble();
			System.out.println("Unestie broj trkača: ");
			int brojTrkaca = unos.nextInt();
			int naStazi = 0;
			for(int i = 0 ; i <= brojTrkaca; i++) {
				System.out.println("Unesite koordinate trkača (x, y): ");
				double x = unos.nextDouble();
				double y = unos.nextDouble();
				double udaljenost = Math.sqrt(Math.pow((x - Cx), 2) + Math.pow((y - Cy), 2));
				
				if(udaljenost >= r1 && udaljenost <= r2 && y >= Cy) {
					naStazi++;
				}
				
				}
			System.out.println("Broj trkača unutar prstena i u gornjem kvadrantu je: " + naStazi);
		}
		}
		
	}

