package vjezbe1;
import java.util.Scanner;
public class RastojanjeMeđuKancelarije {

	public static void main(String[] args) {
		try (Scanner unos = new Scanner(System.in)) {
			System.out.print("Unesite udaljenost među kancelarijama u cm: ");
			double udaljenost = unos.nextDouble();
			double udaljenostUMetrima = udaljenost / 100;
			System.out.printf("Udaljenost među kancelarijama je %.2f metara.%n", udaljenostUMetrima);
		}

	}

}
