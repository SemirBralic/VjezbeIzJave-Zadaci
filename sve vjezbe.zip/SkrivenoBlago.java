package vjezbe1;
import java.util.Scanner;
public class SkrivenoBlago {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite koordinate: ");
		double x1 = sc.nextDouble(), x2 = sc.nextDouble(), y1 = sc.nextDouble(), y2 = sc.nextDouble();
		double blagoX = x2 + 2;
		double blagoY = Math.abs(x2- 3);
		System.out.println("Koordinate blaga su: "+blagoX+" "+blagoY);
		
		double rastojanjeHB = Math.sqrt(Math.pow(y1-blagoY, 2)+Math.pow(blagoX-x1, 2));
		System.out.println("Rastojanje od hrasta do blaga je: "+rastojanjeHB);
		
		double rastojanjeodHK = (Math.pow(y2-y1, 2)+Math.pow(x2-x1, 2));
		double rastojanjeodKB = (Math.pow(blagoY-y2, 2)+Math.pow(blagoX-x2, 2));
		System.out.println("Rastojanje od Hrasta do Blaga ako naidjemo na kucu: "+rastojanjeodHK);
		System.out.println("Rastojanje od Hrasta do kuće je: "+rastojanjeodHK);
		System.out.println("Rastojanje od Hrasta do kuće je: "+rastojanjeodKB);
		double rastojanjeodHKB= rastojanjeodHK+rastojanjeodKB;
		System.out.println("Rastojanje od Hrasta do kuće do blaga je "+rastojanjeodHKB);
		sc.close();
		
	}
//Math.pow(blagoX-x1, 2)
}
