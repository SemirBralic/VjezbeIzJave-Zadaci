package vjezbenedelja4;
/*kreirati program koji ce omoguciti korisniku unos dužine niza i unos elemenata tog niza, a nakon toga prikazati sortiran niz i omogućiti korisniku da unese broj i 
 * provjeriti da li broj postoji u nizu i štampati odgovarajuću poruku
 */
import java.util.Scanner;
public class SortNiz {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite duzinu niza: ");
		int n = sc.nextInt();
		int[] niz = new int[n];
		System.out.println("Unesite elemente niza: ");
		for (int i = 0; i < n; i++) {
			niz[i] = sc.nextInt();
		}
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (niz[i] > niz[j]) {
					int temp = niz[i];
					niz[i] = niz[j];
					niz[j] = temp;
				}
			}
		}
		System.out.println("Sortiran niz: ");
		for (int i = 0; i < n; i++) {
			System.out.print(niz[i] + " ");
		}
		System.out.println();
		System.out.println("Unesite broj koji zelite da provjerite da li postoji u nizu: ");
		int broj = sc.nextInt();
		boolean postoji = false;
		for (int i = 0; i < n; i++) {
			if (niz[i] == broj) {
				postoji = true;
				break;
			}
		}
		if (postoji) {
			System.out.println("Broj " + broj + " postoji u nizu.");
		} else {
			System.out.println("Broj " + broj + " ne postoji u nizu.");
		}
		sc.close();
		

	}

}
