package vjezbe1;
import java.util.Scanner;
public class SrednjaVrijednost {

//Napisati program koji za unijete parametre a i b vraća srednju vrijednost
	
	public static void main(String[] args) {
		
		Scanner unos = new Scanner(System.in);
			System.out.println("Unesite a i b: ");
			double a = unos.nextDouble();
			double b = unos.nextDouble();
			double srednjaVrijednost = (a+b)/2;
			System.out.println("Srednja vrijednost "+a+" i "+b+" je: "+srednjaVrijednost);
			
			unos.close();
	}
}