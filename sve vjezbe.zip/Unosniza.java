package vjezbenedelja4;
/*napraviti program koji omugućava unos dužine niza, a zatim i elemente niza. Svaki element predstavlja broj bodova ostvarenih na ispitu. Nakon unosa potrebno je odštampati
prosjek bodova, i najmanji element u nizu (vrijednost i indeks).*/
import java.util.Scanner;

public class Unosniza {

	public static void main(String[] args) {
		Scanner scanner = new java.util.Scanner(System.in);
		System.out.print("Unesite duzinu niza: ");
		int n = scanner.nextInt();
		int[] niz = new int[n];
		
		for (int i = 0; i < n; i++) {
			System.out.print("Unesite broj bodova " + (i + 1) + ": ");
			niz[i] = scanner.nextInt();
		}
		int suma = 0;
		int min = niz[0];
		int minIndex = 0;
		for (int i = 0; i < n; i++) {
			suma += niz[i];
			if (niz[i] < min) {
				min = niz[i];
				minIndex = i;
			}
		}
		double prosjek = (double) suma / n;
		System.out.println("Prosjek bodova: " + prosjek);
		System.out.println("Najmanji broj bodova: " + min + " na indeksu " + minIndex);
		scanner.close();

	}

}
