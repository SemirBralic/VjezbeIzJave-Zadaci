package vjezbe1;
import java.util.Scanner;
public class ZamijeniVrijednostiXiYzadatak {

	public static void main(String[] args) {
		try (Scanner unos = new Scanner(System.in)) {
			System.out.println("Unesite vrijednost x i y: ");
			int x = unos.nextInt();
			int y = unos.nextInt();
			int privremena = x;
			x = y;
			y = privremena;
			System.out.println("Vrijednost x je: " + x);
			System.out.println("Vrijednost y je: " + y);
		}
	
		
	}
	
}
