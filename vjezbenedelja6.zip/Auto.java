package vjezbenedelja5;
/*Kreirati klasu Auto koja sadrzi sledece atribute: markaAuta, godisteAuta, snagaMotora, prodato (da/ne), kubikazaMotora, registrovan(da/ne).
Povesti racuna o tipovima podataka koje atributi uzimaju. Kreirati odgovarajuce getere i setere. Kreirati konstruktorsku metodu koristeci se this referencom. 
Ukoliko je godiste auta starije od 1985. godine, auto se ne moze registrovati, stoga prilikom pozivanja konstruktorske metode treba povesti racuna o atributu 
registrovan. Precrtati (@override) toString metodu koja stampa objekat klase Auto, formatirati po zelji. 
Kreirati i staticki atribut klase koji prati koliko ima prodatih auta. 
Kreirati staticku metodu klase koja vrace list auta koja se mogu registrovati a koja nijesu registrovana. 
Kreirati staticku metodu kojom se rauna iznos registracije svih auta, ukoliko se auto moze registrovati. 
Neka formula za racunanje inosa registracije bude: koeficijentGodista* kubikaza*snagaMotora, gdje je koeficient godista predstavijen u sledecoj tabeli:
Godiste
Koeficijent Godista
1985-2000
3.0
2001-2010
2.0
2011- present
1.5*/

public class Auto {
    private String markaAuta;
    private int godisteAuta;
    private double snagaMotora;
    private boolean prodato;
    private double kubikazaMotora;
    private boolean registrovan;

    public Auto(String markaAuta, int godisteAuta, double snagaMotora, boolean prodato, double kubikazaMotora, boolean registrovan) {
        this.markaAuta = markaAuta;
        this.godisteAuta = godisteAuta;
        this.snagaMotora = snagaMotora;
        this.prodato = prodato;
        this.kubikazaMotora = kubikazaMotora;
        this.registrovan = godisteAuta < 1985 ? false : registrovan;
        if (prodato) {
            AutoStatistika.povecajBrojProdatih();
        }
    }
    
    
    
    public String getMarkaAuta() {
		return markaAuta;
	}



	public void setMarkaAuta(String markaAuta) {
		this.markaAuta = markaAuta;
	}



	public boolean isProdato() {
		return prodato;
	}



	public void setProdato(boolean prodato) {
		this.prodato = prodato;
	}



	public void setGodisteAuta(int godisteAuta) {
		this.godisteAuta = godisteAuta;
	}



	public void setSnagaMotora(double snagaMotora) {
		this.snagaMotora = snagaMotora;
	}



	public void setKubikazaMotora(double kubikazaMotora) {
		this.kubikazaMotora = kubikazaMotora;
	}



	public void setRegistrovan(boolean registrovan) {
		this.registrovan = registrovan;
	}



	@Override
    public String toString() {
        return String.format("Auto: %s | Godiste: %d | Snaga: %.1f | Kubikaza: %.1f | Registrovan: %s | Prodat: %s",
                markaAuta, godisteAuta, snagaMotora, kubikazaMotora,
                registrovan ? "Da" : "Ne", prodato ? "Da" : "Ne");
    }

    // Geteri za pristup iz drugih klasa
    public int getGodisteAuta() { return godisteAuta; }
    public boolean isRegistrovan() { return registrovan; }
    public double getKubikazaMotora() { return kubikazaMotora; }
    public double getSnagaMotora() { return snagaMotora; }
}

// Vecinu zadatka copilot uradio