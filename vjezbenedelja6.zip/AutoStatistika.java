package vjezbenedelja5;

import java.util.ArrayList;
import java.util.List;

public class AutoStatistika {
    private static int brojProdatihAuta = 0;

    public static void povecajBrojProdatih() {
        brojProdatihAuta++;
    }

    public static int getBrojProdatihAuta() {
        return brojProdatihAuta;
    }

    public static List<Auto> autaZaRegistraciju(List<Auto> sviAuta) {
        List<Auto> rezultat = new ArrayList<>();
        for (Auto auto : sviAuta) {
            if (auto.getGodisteAuta() >= 1985 && !auto.isRegistrovan()) {
                rezultat.add(auto);
            }
        }
        return rezultat;
    }

    public static double iznosRegistracije(List<Auto> sviAuta) {
        double ukupno = 0.0;
        for (Auto auto : sviAuta) {
            if (auto.getGodisteAuta() >= 1985) {
                double koef = KoeficijentGodista.dobaviKoeficijent(auto.getGodisteAuta());
                ukupno += koef * auto.getKubikazaMotora() * auto.getSnagaMotora();
            }
        }
        return ukupno;
    }
}
