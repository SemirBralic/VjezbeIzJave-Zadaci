package vjezbenedelja5;
/*Unijeti rečenicu koja sadrži više riječi. Ispisati broj riječi u rečenici.*/
import java.util.Scanner;
public class BrojRiječi {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite recenicu: ");
		String recenica = sc.nextLine();
		recenica = recenica.trim();
		
		String[] rijeci = recenica.split("\\s+");
		System.out.println("Broj rijeci u recenici je: " + rijeci.length);
		

	}

}
