package vjezbenedelja5;
//U unesenoj rječenici izbrojati koliko ima samoglasnika a koliko suglasnika.
import java.util.Scanner;
public class BrojSamoglasnikaiSuglasnika {

	public static void main(String[] args) {
		Scanner unos = new Scanner(System.in);
		System.out.println("Unesite recenicu: ");
		String recenica = unos.nextLine();
		int brojsamoglasnika = 0;
		int brojsuglasnika = 0;
		recenica = recenica.toLowerCase();
		for (int i = 0; i < recenica.length(); i++) {
			char znak = recenica.charAt(i);
			if (znak >= 'a' && znak <= 'z') {
				if (znak == 'a' || znak == 'e' || znak == 'i' || znak == 'o' || znak == 'u') {
					brojsamoglasnika++;
				} else {
					brojsuglasnika++;
				}
			}
		}
		System.out.println("Broj samoglasnika je: " + brojsamoglasnika);
		System.out.println("Broj suglasnika je: " + brojsuglasnika);
		unos.close();

	}

}
