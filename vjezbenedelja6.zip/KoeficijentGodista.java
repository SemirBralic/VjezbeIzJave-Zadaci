package vjezbenedelja5;

public class KoeficijentGodista {
    public static double dobaviKoeficijent(int godiste) {
        if (godiste >= 1985 && godiste <= 2000) {
            return 3.0;
        } else if (godiste >= 2001 && godiste <= 2010) {
            return 2.0;
        } else if (godiste >= 2011) {
            return 1.5;
        } else {
            return 0.0;
        }
    }
}
