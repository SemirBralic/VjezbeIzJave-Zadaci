package vjezbenedelja5;
// Napisati program koji provjerava da li je uneseni string palindrom. Koristiti StringBuilder i metod reverse().
import java.util.Scanner;
public class Palindrom {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.print("Unesite string: ");
        String riječ = sc.nextLine().trim();
        
        String bezRazmaka = riječ.replaceAll("\\s+", "");
        StringBuilder sb = new StringBuilder(bezRazmaka);
        String reversed = sb.reverse().toString();
        
        if (bezRazmaka.equalsIgnoreCase(reversed)) {
            System.out.println("Uneseni string je palindrom.");
        } else {
            System.out.println("Uneseni string nije palindrom.");
        }

        sc.close();
    }
}