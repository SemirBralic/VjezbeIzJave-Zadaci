package vjezbenedelja5;
//Dat je string u kojem se neka dva uzastopna slova ponavljaju. Pronaći koja su to slova.
import java.util.Scanner;
public class PonavljanjeSlova {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite string: ");
		String rijec = sc.nextLine();
		
		boolean nadjeno = false;
				
		for (int i = 0; i < rijec.length() - 1; i++) {
			if (rijec.charAt(i) == rijec.charAt(i + 1)) {
				System.out.println("Ponovljena slova: " + rijec.charAt(i) + rijec.charAt(i + 1));
				nadjeno = true;
			}
	
		}
		if (!nadjeno) {  //! znači negaciju, ako nije nadjeno
			System.out.println("Nema ponovljenih uzastopnih slova.");
		}
	}

}
