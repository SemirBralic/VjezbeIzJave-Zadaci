package vjezbenedelja5;

public enum Student {
    // 🔢 Definisanje konstanti sa ocjenama iz 3 predmeta
    SEMIR_BRALIC(8, 9, 10),
    MILICA_JOVANOVIC(10, 10, 9),
    NIKOLA_STOJIC(7, 8, 6),
    JELENA_MILANOVIC(9, 9, 9),
    IVAN_ANTIC(6, 7, 8);

    // 📚 Atributi ocjena
    private int ocena1;
    private int ocena2;
    private int ocena3;

    // 🏗️ Konstruktor
    Student(int ocena1, int ocena2, int ocena3) {
        this.ocena1 = ocena1;
        this.ocena2 = ocena2;
        this.ocena3 = ocena3;
    }

    // 📊 Metoda za računanje prosjeka
    public double izracunajProsek() {
        return (ocena1 + ocena2 + ocena3) / 3.0;
    }

    // 🧾 Metoda za formatirano ime
    public String getImeIPrezime() {
        return this.name().replace("_", " ");
    }
}

//Prvi put vidim ovo pa sam koristio copilot. Mislio sam da će biti kompleksnije ali sam vidio da je kao što je u klase bilo.

