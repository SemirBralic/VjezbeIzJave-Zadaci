package vjezbenedelja5;

public class TestStudent {

	public static void main(String[] args) {
		
		System.out.println("Studenti i njihovi prosjeci:\n");

			for (Student s : Student.values()) {
				System.out.printf("%s → Prosjek: %.2f\n", s.getImeIPrezime(), s.izracunajProsek());

			}
		 }
	}